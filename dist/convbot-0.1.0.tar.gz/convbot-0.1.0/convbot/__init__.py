"""Init."""
__version__ = "0.1.0"
from .convbot import convbot

__all__ = ("convbot",)
